package com.cod.AniBirth.global.security.exception;

public class MemberNotFoundException extends RuntimeException {
}
