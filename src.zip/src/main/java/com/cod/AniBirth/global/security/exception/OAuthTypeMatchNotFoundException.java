package com.cod.AniBirth.global.security.exception;

public class OAuthTypeMatchNotFoundException extends RuntimeException {
}
